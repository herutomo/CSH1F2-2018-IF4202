angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('playsTv', {
    url: '/page1',
    templateUrl: 'templates/playsTv.html',
    controller: 'playsTvCtrl'
  })

  .state('loginToPlaysTv', {
    url: '/page2',
    templateUrl: 'templates/loginToPlaysTv.html',
    controller: 'loginToPlaysTvCtrl'
  })

  .state('registrasi', {
    url: '/page3',
    templateUrl: 'templates/registrasi.html',
    controller: 'registrasiCtrl'
  })

  .state('mobileLegendStream', {
    url: '/page4',
    templateUrl: 'templates/mobileLegendStream.html',
    controller: 'mobileLegendStreamCtrl'
  })

  .state('aboutMe', {
    url: '/page5',
    templateUrl: 'templates/aboutMe.html',
    controller: 'aboutMeCtrl'
  })

  .state('cSGOLiveStream', {
    url: '/page6',
    templateUrl: 'templates/cSGOLiveStream.html',
    controller: 'cSGOLiveStreamCtrl'
  })

  .state('pUBGLiveStream', {
    url: '/page7',
    templateUrl: 'templates/pUBGLiveStream.html',
    controller: 'pUBGLiveStreamCtrl'
  })

$urlRouterProvider.otherwise('/page1')


});